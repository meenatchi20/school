<?php

namespace App\Providers;
use Laravel\Passport\Passport;
use App\Policies\StudentPolicy;
use Illuminate\Support\Facades\Gate;
use App\Models\Student;
use App\Models\User;


use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
         User::class => StudentPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        Passport::tokensExpireIn(now()->addMinutes(1));
        Passport::refreshTokensExpireIn(now()->addMinutes(1));
        Passport::personalAccessTokensExpireIn(now()->addMinutes(1));
        
    Gate::define('admin',function($user){
        return in_array($user->role,['Admin', 'SuperAdmin']);
        });

    }
}
