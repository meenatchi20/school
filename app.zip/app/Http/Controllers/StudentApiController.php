<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use App\Services\CommonService;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\StudentAuthRequest;
use App\Http\Requests\studentLoginRequest;
use App\Http\Resources\StudentResource;
use App\Http\Requests\ImportStudentRequest;
use PDF;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Log;

class StudentApiController extends Controller
{
            //Show Student List
            public function index(Request $request,Student $student,CommonService $studentData)
            {
                 $students = $studentData->getAllStudentData();
                    if($students){
                       return StudentResource::collection($students);
                    }
                    else{
                        return response()->json([
                            'success' => false,
                            'error'=> 'something wrong'
                         ]);
                    }
            }

            //Store STudent Data 
            public function store(StoreUserRequest $request, CommonService $storeStudentData){
            
                $data = $request->validated();
                 try{
                     $students = $storeStudentData->storeStudentData($data);
                        if($students) {
                            return response()->json([
                                'success' => true,
                                'message' => 'student Data added successfully',
                                'data' => $students
                            ]);
                        }
                        else{
                            return response()->json([
                                'success' => false,
                                'error'=> 'something wrong'
                         ]);
                        } 

                }
                catch(Exception  $e){
                    Log::error('something unwanted',$e->getMessage());
                }

            }   

            //Edit studentdata 
             public function edit(string $id,CommonService $editStudentData){
            
                $student = $editStudentData->editStudentData($id);
                    if($student){
                        return response()->json([
                            'success' => true,
                            'data' => $student
                        ]);
                    }
                    else{
                         return response()->json([
                            'success' => false,
                            'error'=> 'something wrong'
                         ]);
                    }
                }

            //Update StudentData 
             public function update(StoreUserRequest $request, string $id, CommonService $updateStudentData)
                {
                    $data =  $request->validated();
                try{
                        $student = $updateStudentData->updateStudentData($data,$id);
                        if($student){
                        return response()->json([
                        'success' => 'true',
                        'message' => 'Updated successfully',
                        'data' => $student
                        ]);
                    }else {
                        return response()->json([
                        'success' => false,
                        'error'=> 'something wrong'
                        ]);
                    }
                }
                catch(Exception $e){
                    Log::error('something unwanted',$e->getMessage());
                }
            }

            

            
            //student Data export Excel
             public function studentExcelExport(CommonService $exportStudentData){
                $result = $exportStudentData->exportStudentData();
                if ($result) {
                    return response()->json([
                            'success' => true,
                            'message' => 'student data successfully exported in excel',
                            'Data' => $result
                            
                        ]);
                }
                else {
                        return response()->json([
                            'success' => false,
                            'error' =>'something wrong'
                        ]);
                    }
            }

            //Show Excel Export Status(user,Status)
             public function ExportStatus(CommonService $ExportStatus){
                $exportDatas = $ExportStatus->ExportStatus();
                if($exportDatas){
                    return response()->json([
                        'success'=>true,
                        'data'=>$exportDatas
                    ]);
                }
                else{
                    return response()->json([
                    'success'=>false,
                    'error'=>'something wrong'
                   ]); 
                }
            }

            //Show Student Mark List
             public function studentmarkData(CommonService $studentMarks){
                $data = $studentMarks->studentMark();
                if($data){
                    return response()->json([
                        'success'=>true,
                        'data'=> $data
                    ]);
                }
                else{
                    return response()->json([
                        'success' => false,
                        'error' => 'something wrong'
                    ]);
                }
            } 

             //Import Student Mark(PhoneNo) Using Excel 
            public function ImportStudentMark(ImportStudentRequest $request,CommonService $importStudentData){
                   
                    $importMark = $importStudentData->importStudentMark($request);
                            if($importMark){
                                return response()->json([
                                    'success'=>true,
                                    'data'=> $importMark
                                ]);
                            }
                            else{
                                return response()->json([
                                    'success' => false,
                                    'error' => 'something wrong'
                                ]);
                            }    
                        }

             //Import Student Data Using Excel 
             public function ImportStudentData(ImportStudentRequest $request,CommonService $importStudentData){        
                            $importData = $importStudentData->importStudentData($request);
                            if($importData){
                                return response()->json([
                                    'success'=>true,
                                    'data'=> $importData
                                ]);
                            }
                            else{
                                return response()->json([
                                    'success' => false,
                                    'error' => 'something wrong'
                                ]);
                            }
                           
                        }

            //Search StudentData
             public function searchField(Request $request,CommonService $searchDatas){

                     $searchField = $request->all();
                     try{
                     $students = $searchDatas->searchData($searchField);
                     $searchdata = $request->input('Pdf');

                     if ( $searchdata == 'Pdf') {
                         $students = $searchDatas->searchData($searchField, $paginate=false);
                         $pdf = PDF::loadView('student_pdf', compact('students'));
                         //$exportPdf = $pdf->download('student_filtered.pdf');
                            // return response()->json([
                            //     'success' => true,
                            //     'message' => 'PDF Uploaded successfully.',
                            //     //'pdf_base64' => base64_encode($pdf->output())
                            //     //'download pdf' => base64_decode($exportPdf)
                                
                            //  ]);

                         return response($pdf->output(), 200, [
                                'Content-Type' => 'application/pdf',
                                'Content-Disposition' => 'inline; filename="studentdata.pdf"'
                            ]);
                     };
                    return StudentResource::collection($students);
                       
                  

                   }catch(Exception $e){
                        Log::error('something error' . $e->getMessage());
                   }   
             }
            
             //Delete StudentData
              public function destroy(string $id,CommonService $deleteStudentData){

                   $student = $deleteStudentData->deleteStudentData($id);
                   if($student){
                        return response()->json([
                            'message' => 'studentdata is deleted successsfully',
                            'student_id' => $id
                        ]);
                   }

            }

              
}
