<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Http\Requests\StudentAuthRequest;
use App\Http\Requests\studentLoginRequest;
use App\Services\CommonService;


class AuthApiController extends Controller
{
            //Login 
            public function login(studentLoginRequest $request,CommonService $login){
                $data = $request->validated();
                $loginData = $login->login($data);
                if(!Auth::attempt($loginData)){
                    return response([
                        'error'=> 'Invalid Details'
                    ]);
                }

                $token = auth()->user()->createToken('ApiToken')->accessToken;

                    return response([
                        'message'=> 'login successfully',
                        'data' => auth()->user(),
                         'token' => $token
                    ]);

                }

            //SignUp
            public function signUpCreate(StudentAuthRequest $request,CommonService $signUp){
                $datas = $request->validated();
                $data = $signUp->signUpCreate($datas);
                if($data){
                return response([
                    'success' => true,
                    'message' => 'signup successfully',
                    'data' => $data
                    ]);
                }
                else {
                    return response([
                        'success' => false,
                        'error'=> 'something wrong'
                    ]);
                }
            }

            //Logout 
            public function logout(Request $request){
               $request->user()->token()->revoke();

                return response()->json([
                    'success' => true,
                    'message' => 'User logged out successfully.'
                ]);
            }  
}
