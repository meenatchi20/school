<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;
    //Excel Import StudentData
    // public function ImportStudentData(ImportStudentRequest $request,CommonService $importStudentData){
    //      $importStudentData->importStudentData($request);
    //      return redirect()->route('student.list')->with('success','file upload successfully');
    // }

   

    //Excel Export Student Mark USing PhoneNumber
    // public function ImportStudentMark(Request $request){
    //      $file = $request->file('student_file');
    //      Excel::import(new StudentPhoneNoImport, $file);
    //      return redirect()->route('student.list')->with('success','file upload successfully');
    // }

 // public function downloadPdf(){
    //     $students = Student ::with(['department','subject'])->get();
    //     $pdf = PDF::loadView('student_pdf',compact('students'));
    //     return $pdf->download('student.pdf');
    // }

    // Excel Export StudentData
    // public function studentExcelExport(CommonService $exportStudentData){
    //     return $exportStudentData->exportStudentData();
    // }

    // select * from `student` where exists (select * from `subjects` inner join `student_mapping` on `subjects`.`id` = `student_mapping`.`subject_id` where `student`.`id` = `student_mapping`.`student_id` and `subjects`.`id` in (2,6,1));

}
