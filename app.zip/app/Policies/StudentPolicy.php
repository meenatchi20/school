<?php

namespace App\Policies;

use App\Models\Student;
use App\Models\User;
use Illuminate\Auth\Access\Response;

class StudentPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
         return in_array($user->role, ['Admin', 'SuperAdmin','Manager','User']);
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return in_array($user->role, ['Admin', 'SuperAdmin','Manager']);
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, Student $student): bool
    {
        return in_array($user->role, ['Admin', 'SuperAdmin','Manager']);
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Student $student): bool
    {
        return $user->role === 'SuperAdmin';
    }

     public function studentMark(User $user): bool
    {
         return in_array($user->role, ['Admin', 'SuperAdmin','Manager','User']);
    }

    public function markUpload(User $user, $type): bool
    {
        return in_array($user->role, ['Admin', 'SuperAdmin']);
    }

    public function pdfExcelExport(User $user,$type): bool
    {
        return in_array($user->role, ['Admin', 'SuperAdmin']);

    }

}
